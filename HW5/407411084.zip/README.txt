學號：407410084
姓名：吳岳
環境：csie2
E-mail：thehill@csie.io
簡介：
這次實作bigint,我把範例的測資跟我自己的一些測資放在main.cpp裡，然後用makefile把他變成一個test的執行檔。

學號：407410084
姓名：吳岳
環境：csie0.cs.ccu.edu.tw
Email : thehill@csie.io
簡介：如作業規定照做
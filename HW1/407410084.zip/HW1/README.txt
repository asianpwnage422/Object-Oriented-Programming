1.本次的作業學會(1)C++與Java的一些特別的語法(2)makefile(3)debugger使用方式
2.程式有與同學一起討論
